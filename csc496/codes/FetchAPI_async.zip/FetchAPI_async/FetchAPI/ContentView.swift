// ContentView.swift
// FetchAPI
// Created by SI CHEN on 10/03/23.

import SwiftUI

struct ContentView: View {
    // Initialize the APIData observable object
    @ObservedObject var apiData = APIData(PokemonID: 1)
    
    // State variables to store and manipulate UI data
    @State var pokemonID: Int = 1
    @State var pokemonID_String: String = ""
    
    var body: some View {
        VStack {
            // Format Pokemon ID to a 3-digit string (e.g., "001" for 1)
            let pokemonID_string = String(format: "%03d", self.pokemonID)
            
            // Display Pokemon image, name, and attributes
            Image(pokemonID_string)
            Text("Name: \(apiData.pokemonName)")
                .font(.system(size: 20).weight(.heavy))

            // Text field for entering a Pokemon ID
            TextField("Pokemon ID", text: $pokemonID_String)
                .multilineTextAlignment(.center)
                .padding(6.0)
                .background(
                    RoundedRectangle(cornerRadius: 4.0, style: .continuous)
                        .stroke(.gray, lineWidth: 1.0)
                )
                .padding()
            
            // Button to fetch new data based on entered ID
            Button("Search") {
                self.pokemonID = Int(pokemonID_String) ?? 0
                apiData.fetchNew(PokemonID: self.pokemonID)
            }
            .tint(.green)
            .controlSize(.large)
            .buttonStyle(.borderedProminent)
            
            HStack(spacing: 40) {
                Button(action: {
                    if pokemonID > 0 {
                        pokemonID -= 1
                        apiData.fetchNew(PokemonID: self.pokemonID)

                    }
                    
                }) {
                    Text("↓")
                        .font(.largeTitle)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Circle())
                }

                Button(action: {
                    pokemonID += 1
                    apiData.fetchNew(PokemonID: self.pokemonID)

                }) {
                    Text("↑")
                        .font(.largeTitle)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Circle())
                }
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
