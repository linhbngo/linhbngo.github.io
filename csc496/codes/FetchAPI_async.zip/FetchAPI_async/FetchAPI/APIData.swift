// APIData.swift
// FetchAPI
// Created by Dr. CHEN on 10/04/23.

import Foundation

// APIData class conforms to ObservableObject for data binding with SwiftUI views.
class APIData: ObservableObject {
    
    // State variables for holding various attributes of a Pokémon.
    @Published var pokemonName: String = ""

    
    // Initializer fetches data for a Pokémon based on the given Pokémon ID.
    init(PokemonID: Int) {
        Task {
            do {
                let PokemonData = try await self.fetchAPIData(for: PokemonID)
                self.updateState(with: PokemonData)
            } catch {
                print(error.localizedDescription)
            }
        }
    }

    func fetchNew(PokemonID: Int) {
        Task {
            do {
                let PokemonData = try await self.fetchAPIData(for: PokemonID)
                self.updateState(with: PokemonData)
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
    
    // Helper method to update the state variables.
    private func updateState(with PokemonData: PokemonData) {
        self.pokemonName = PokemonData.name
    }
    
    // Method to fetch Pokémon data from API.
    // completionHandler is called when data is successfully fetched and decoded.
    private func fetchAPIData(for pokemonID: Int) async throws -> PokemonData {
        let url = URL(string: "https://pokemon.wcpc.fun/id/\(pokemonID)")!
        let (data, _) = try await URLSession.shared.data(from: url)
        return try JSONDecoder().decode(PokemonData.self, from: data)
    }
}
