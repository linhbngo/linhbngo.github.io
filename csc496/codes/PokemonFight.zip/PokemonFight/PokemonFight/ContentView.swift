//
//  ContentView.swift
//  PokemonFight
//
//  Created by SI CHEN on 9/20/23.
//

import SwiftUI

// ContentView is the primary View struct containing the app's UI components.
struct ContentView: View {
    
    // MARK: - State Variables
    
    /// Text that holds the status of the battle.
    @State var result: String = "Let's fight!"
    
    /// Random numbers to represent each Pokémon (used for their images).
    @State var randomNumber1 = Int.random(in: 1...100)
    @State var randomNumber2 = Int.random(in: 1...100)
    
    /// Bool variables to control shake animations for each Pokémon.
    @State var pokemon1Shake: Bool = false
    @State var pokemon2Shake: Bool = false
    
    // MARK: - Body
    
    /// The main View content.
    var body: some View {
        // Text to display the result of the battle.
        Text(result)
            .padding()
        
        // Generate image names for Pokémon based on random numbers.
        let pokemon1: String = String(format: "%03d", randomNumber1)
        let pokemon2: String = String(format: "%03d", randomNumber2)
        
        // UI layout.
        VStack {
            // Pokémon images.
            HStack {
                // First Pokémon.
                VStack {
                    // Use offset for shake animation.
                    // (Tip: For students - look into GeometryEffect for more complex animations)
                    Image(pokemon1).offset(x: pokemon1Shake ? -10 : 0)
                }
                
                // Second Pokémon.
                VStack {
                    Image(pokemon2).offset(x: pokemon2Shake ? -10 : 0)
                }
            }
            
            // Buttons for interaction.
            // Add your code here
            Button("Attack!") {
                // Animate shaking for only the attacker.
                // (Tip: For students - use conditions to choose which Pokémon to animate)
                withAnimation {
                    self.pokemon1Shake.toggle()
                }
            }
            
            // Reset the game state.
            // Add your code here
            Button("Replay") {
                randomNumber1 = Int.random(in: 1...100)
                randomNumber2 = Int.random(in: 1...100)
            }
        }
    }
}

// Preview ContentView.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// Custom GeometryEffect for more complex animations.
struct Shake: GeometryEffect {
    var amount: CGFloat = 10
    var shakesPerUnit = 3
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: amount * sin(animatableData * .pi * CGFloat(shakesPerUnit)), y: 0))
    }
}
