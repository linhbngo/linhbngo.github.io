import Foundation
import Alamofire
import Combine

class APIData: ObservableObject {
    
    @Published var pokemonName: String = ""

    init(PokemonID: Int) {
        fetchAPIData(pokemonID: PokemonID)
    }
    
    func fetchNew(PokemonID: Int) {
        fetchAPIData(pokemonID: PokemonID)
    }
    
    private func fetchAPIData(pokemonID: Int) {
        let url = "https://pokemon.wcpc.fun/id/\(pokemonID)"
        
        AF.request(url).validate().responseDecodable(of: PokemonData.self) { response in
            switch response.result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.pokemonName = data.name
                }
            case .failure(let error):
                print("Error: \(error.localizedDescription)")
            }
        }
    }
}
