//
//  _rdpartyApp.swift
//  3rdparty
//
//  Created by SI CHEN on 10/23/23.
//

import SwiftUI

@main
struct _rdpartyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
