import UIKit

let sumClosure = { (a: Int, b: Int) -> Int in
   return a + b
}
let result = sumClosure(5,8)   // 13
print(result)


var number = 5
let incrementer = { [number] in
    print(number + 1)
}
number = 6
incrementer()

func makeIncrementer() -> () -> Int {
    var counter = 0
    let incrementer: () -> Int = {
        counter += 1
        return counter
    }
    return incrementer
}

func doSomething(escapingClosure: @escaping () -> Void) {
    DispatchQueue.main.async {
        escapingClosure()
    }
}


enum DungeonRoom {
    case treasureRoom(Int)
    case monsterRoom(String)
    case emptyRoom
}

func describeRoom(room: DungeonRoom) -> String {
    switch room {
    case .treasureRoom(let goldAmount):
        return "This is a treasure room with \(goldAmount) gold coins."
    case .monsterRoom(let monsterType):
        return "This is a monster room with a \(monsterType)."
    case .emptyRoom:
        return "This is an empty room."
    }
}

// Usage:
let description = describeRoom(room: .monsterRoom("Dragon"))
print(description)  // Output: "This is a monster room with a Dragon."
