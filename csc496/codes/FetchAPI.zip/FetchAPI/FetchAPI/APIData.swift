// APIData.swift
// FetchAPI
// Created by Dr. CHEN on 10/04/23.

import Foundation

// APIData class conforms to ObservableObject for data binding with SwiftUI views.
class APIData: ObservableObject {
    
    // State variables for holding various attributes of a Pokémon.
    @Published var pokemonName: String = ""

    
    // Initializer fetches data for a Pokémon based on the given Pokémon ID.
    init(PokemonID: Int) {
        fetchAPIData(completionHandler: { PokemonData in
            self.updateState(with: PokemonData)
        }, pokemonID: PokemonID)
    }
    
    func fetchNew(PokemonID: Int) {
        fetchAPIData(completionHandler: { PokemonData in
            self.updateState(with: PokemonData)
        }, pokemonID: PokemonID)
    }
    
    // Helper method to update the state variables.
    private func updateState(with PokemonData: PokemonData) {
        self.pokemonName = PokemonData.name
    }
    
    // Method to fetch Pokémon data from API.
    // completionHandler is called when data is successfully fetched and decoded.
    private func fetchAPIData(completionHandler: @escaping (PokemonData) -> Void, pokemonID: Int) {
        let url = URL(string: "https://pokemon.wcpc.fun/id/\(pokemonID)")!
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            
            do {
                let pokemonData = try JSONDecoder().decode(PokemonData.self, from: data)
                
                // Move to the main thread
                DispatchQueue.main.async {
                    completionHandler(pokemonData)
                }
            } catch {
                print(error.localizedDescription)
            }
        }.resume()
    }
}
