//
//  GameScene.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    let player = Player()
    
    // labels
    var scoreLevel: SKLabelNode = SKLabelNode()
    var score: Int = 0{
        didSet{
            scoreLevel.text = "Score: \(score)"
        }
    }
    var missedCount = 0
    var maxAllowedMisses = 5
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        
        let background = SKSpriteNode(imageNamed: "background")
        background.anchorPoint = CGPoint(x: 0, y: 0)
        background.position = CGPoint(x: 10, y: 330)
        background.zPosition = Layer.background.rawValue
        addChild(background)
        
        let foreground = SKSpriteNode(imageNamed: "foreground")
        foreground.anchorPoint = CGPoint(x: 0, y: 0)
        foreground.position = CGPoint(x: 15, y: 158)
        foreground.zPosition = Layer.foreground.rawValue
        foreground.physicsBody = SKPhysicsBody(edgeLoopFrom: foreground.frame)
        foreground.physicsBody?.affectedByGravity = false
        
        foreground.physicsBody?.categoryBitMask = PhysicsCategory.foreground
        foreground.physicsBody?.contactTestBitMask = PhysicsCategory.collectible
        foreground.physicsBody?.collisionBitMask = PhysicsCategory.none
        addChild(foreground)
        
        
        player.position = CGPoint(x: size.width/2, y: foreground.frame.maxY)
        player.setupConstraints(floor: foreground.frame.maxY)
        addChild(player)
        spawnMultipleFruits()
        setupLabels()
    }
    
    func spawnFruit(){
        let collectible = Collectible(collectibleType: CollectibleType.fruit)
        
        // set random position
        let margin = collectible.size.width * 2
        let dropRange = SKRange(lowerLimit: frame.minX + margin, upperLimit: frame.maxX - margin)
        let randomX = CGFloat.random(in: dropRange.lowerLimit...dropRange.upperLimit)
        collectible.position = CGPoint(x: randomX, y: player.position.y * 2.5)
        //collectible.position = CGPoint(x: player.position.x, y: player.position.y * 2.5)
        addChild(collectible)
        collectible.drop(dropSpeed: TimeInterval(1.0), floorLevel: player.frame.minY)
    }
    func setupLabels(){
        scoreLevel.name = "score"
        scoreLevel.fontColor = .red
        scoreLevel.fontSize = 55.0
        scoreLevel.horizontalAlignmentMode = .right
        scoreLevel.verticalAlignmentMode = .center
        scoreLevel.zPosition = Layer.ui.rawValue
        scoreLevel.position = CGPoint(x:frame.maxX - 50, y: 700)
        scoreLevel.text = "Score: 0"
        addChild(scoreLevel)
    }
    
    func restartGame() {
        score = 0
        missedCount = 0
        enumerateChildNodes(withName: "//co_*") { (node, _) in
            node.removeFromParent()
        }
        enumerateChildNodes(withName: "restartButton") { (node, _) in
            node.removeFromParent()
        }

        spawnMultipleFruits()
    }
    
    
    func gameOver(){
        removeAction(forKey: "fruit")
        
        enumerateChildNodes(withName: "//co_*"){
            (node, stop) in
            node.removeAction(forKey: "drop")
            node.physicsBody = nil
        }
        
        let restartButton = SKSpriteNode(color: .blue, size: CGSize(width: 120, height: 60))
        restartButton.position = CGPoint(x: frame.midX, y: frame.midY)
        restartButton.name = "restartButton"
        restartButton.zPosition = Layer.ui.rawValue
        addChild(restartButton)

        let buttonText = SKLabelNode(text: "Restart")
        buttonText.fontColor = .white
        buttonText.fontSize = 30
        buttonText.verticalAlignmentMode = .center
        restartButton.addChild(buttonText)
    }
    func spawnMultipleFruits(){
        let wait = SKAction.wait(forDuration: TimeInterval(1.0))
        let spawn = SKAction.run{
            self.spawnFruit()
        }
        let sequence = SKAction.sequence([wait, spawn])
        let repeatAction = SKAction.repeat(sequence, count: 10)
        run(repeatAction, withKey: "fruit")
    }
    func touchDown(atPoint pos: CGPoint){
        if pos.x < player.position.x{
            player.moveToPosition(pos: pos, direction: "L", speed: 1.0)
        }
        else{
            player.moveToPosition(pos: pos, direction:"R", speed: 1.0)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let nodes = nodes(at: location)
            
            if nodes.contains(where: { $0.name == "restartButton" }) {
                // restart game
                restartGame()
            } else {
                self.touchDown(atPoint: location)
            }
        }
    }

}

extension GameScene:SKPhysicsContactDelegate{
    func didBegin(_ contact: SKPhysicsContact) {
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        print(collision)
        if collision == PhysicsCategory.player | PhysicsCategory.collectible{
            print("player hit collectible")
            score += 10
            let body = contact.bodyA.categoryBitMask == PhysicsCategory.collectible ? contact.bodyA.node : contact.bodyB.node
            if let sprite = body as? Collectible{
                sprite.collected()
            }
        }
        
        if collision == PhysicsCategory.foreground | PhysicsCategory.collectible{
            print("collectible hit foreground")
            
            let body = contact.bodyA.categoryBitMask == PhysicsCategory.collectible ? contact.bodyA.node : contact.bodyB.node
            
            if let sprite = body as? Collectible{
                sprite.missed()
                missedCount += 1
                if missedCount >= maxAllowedMisses {
                    gameOver()
                }
            }
        }
    }
}
