//
//  SpriteKitHelper.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import Foundation
import SpriteKit

enum Layer:CGFloat{
    case background
    case foreground
    case player
    case collectible
    case ui
}

// SpriteKit Physics Categories
enum PhysicsCategory{
    static let none: UInt32 = 0
    static let player: UInt32 = 0b1 // 1
    static let collectible: UInt32 = 0b10 // 2
    static let foreground: UInt32 = 0b100 // 4
    
}
