//
//  GameViewController.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create the view
        
        if let view = self.view as! SKView?{
            let scene = GameScene(size:CGSize(width: 1336, height: 1024))
            
            scene.scaleMode = .aspectFill
            
            scene.backgroundColor = UIColor(red: 105/255, green: 157/255, blue: 181/255, alpha: 1)
            
            view.presentScene(scene)
            
            view.ignoresSiblingOrder = false
            view.showsPhysics = false
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
