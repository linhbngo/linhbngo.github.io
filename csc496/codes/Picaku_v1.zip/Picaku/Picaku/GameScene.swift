//
//  GameScene.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    let player = Player()

    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "background")
        background.anchorPoint = CGPoint(x: 0, y: 0)
        background.position = CGPoint(x: 10, y: 330)
        background.zPosition = Layer.background.rawValue
        addChild(background)
        
        let foreground = SKSpriteNode(imageNamed: "foreground")
        foreground.anchorPoint = CGPoint(x: 0, y: 0)
        foreground.position = CGPoint(x: 15, y: 158)
        foreground.zPosition = Layer.foreground.rawValue
        addChild(foreground)
        
        
        player.position = CGPoint(x: size.width/2, y: foreground.frame.maxY)
        addChild(player)
    }
    
    func touchDown(atPoint pos: CGPoint){
        player.moveToPosition(pos: pos, speed: 1.0)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches{self.touchDown(atPoint: t.location(in: self))}
    }
}
