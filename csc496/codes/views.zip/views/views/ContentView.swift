//
//  ContentView.swift
//  views
//
//  Created by SI CHEN on 10/31/23.
//

import SwiftUI

struct ContentView: View {
    @State private var showProfile = false

    var body: some View {
        if showProfile {
            UserProfileView()
            Button("Back") {
                showProfile = false
            }
        } else {
            Button("Profile") {
                showProfile = true
            }
        }
    }
}
#Preview {
    ContentView()
}


//struct ContentView: View {
//    @State private var showProfile = false
//
//    var body: some View {
//        NavigationView {
//            if showProfile {
//                UserProfileView()
//                    .navigationBarTitle("User Profile", displayMode: .inline)
//                    .navigationBarItems(trailing: Button("Back") {
//                        showProfile = false
//                    })
//            } else {
//                Button("Profile") {
//                    showProfile = true
//                }
//            }
//        }
//    }
//}
