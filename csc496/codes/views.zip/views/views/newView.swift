//
//  newView.swift
//  views
//
//  Created by SI CHEN on 10/31/23.
//
import SwiftUI

struct UserProfileView: View {
    var body: some View {
        VStack {
            UserAvatarView()
            UserNameView()
            UserBioView()
        }
    }
}

struct UserAvatarView: View {
    var body: some View {
        Image(systemName: "person.circle.fill")
            .resizable()
            .frame(width: 100, height: 100)
    }
}

struct UserNameView: View {
    var body: some View {
        Text("John Doe")
            .font(.title)
    }
}

struct UserBioView: View {
    var body: some View {
        Text("I love SwiftUI!")
            .font(.subheadline)
    }
}
