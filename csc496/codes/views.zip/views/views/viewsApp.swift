//
//  viewsApp.swift
//  views
//
//  Created by SI CHEN on 10/31/23.
//

import SwiftUI

@main
struct viewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
