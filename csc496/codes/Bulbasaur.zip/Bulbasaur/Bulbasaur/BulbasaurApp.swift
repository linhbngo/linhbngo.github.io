//
//  BulbasaurApp.swift
//  Bulbasaur
//
//  Created by student on 10/3/23.
//

import SwiftUI

@main
struct BulbasaurApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
