//
//  ContentView.swift
//  Bulbasaur
//
//  Created by student on 10/3/23.
//

import SwiftUI



struct ContentView: View {
    @StateObject var b = Bulbasaur()
    
    var body: some View {
        VStack {
            Text("lv: \(b.getLevel())")
            Text(b.getName())
            Image(b.getName())
            Button("Level up"){
                let current_level = b.getLevel()
                b.setLevel(lv: current_level + 1)
            }
            Button("Reset"){
                b.setLevel(lv: 1)
            }

        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
