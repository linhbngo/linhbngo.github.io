//
//  Bulbasaur.swift
//  Bulbasaur
//
//  Created by student on 10/3/23.
//

import Foundation

class Bulbasaur: ObservableObject{
    @Published private var id: Int = 1
    @Published private var level: Int = 1
    
    init() {
        self.id = 1
        self.level = 1
    }
    
    func setLevel(lv: Int){
        self.level = lv
        if(level >= 16 && level < 32){
            self.id = 2
        }
        else if (level >= 32){
            self.id = 3
        } else {
            self.id = 1
        }
    }
    
    func getLevel() -> Int {
        return self.level
    }
    func getName() -> String{
        switch self.id{
        case 1:
            return "bulbasaur"
        case 2:
            return "ivysaur"
        case 3:
            return "venusaur"
        default:
            return "bulbasaur"
        }
    }
    func getID() -> Int{
        return self.id
    }
}
