//
//  ConcurrencyDemoApp.swift
//  ConcurrencyDemo
//
//  Created by SI CHEN on 10/11/22.
//

import SwiftUI

@main
struct ConcurrencyDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
