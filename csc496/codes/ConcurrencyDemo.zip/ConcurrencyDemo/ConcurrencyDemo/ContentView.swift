//
//  ContentView.swift
//  ConcurrencyDemo
//
//  Created by SI CHEN on 10/11/22.
//

import SwiftUI

struct ContentView: View {
    @State private var backgroudIsGreen = false
    @State private var data: String = "Fetching data..."

    var body: some View {
        ZStack{
            Color(backgroudIsGreen ? .green : .white)
            VStack {
                
                Text(data).padding()
                Button("Download Pokemon Data"){
                    DownloadPokemonData()
                }
                Button("Change Background"){
                    self.backgroudIsGreen.toggle()
                }
            }
            .padding()
        }
    }
    
    func DownloadPokemonData() -> Void{
        DispatchQueue.global(qos: .background).async{
            sleep(2)
            
            let fetchedData = "Data fetched successfully!"

            // Update the UI on the main thread
            DispatchQueue.main.async {
                data = fetchedData
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


