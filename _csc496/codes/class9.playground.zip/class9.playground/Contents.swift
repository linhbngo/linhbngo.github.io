import UIKit

var greeting = "Hello, playground"


class Dog{
    var name: String
    
    init(name: String){
        self.name = name
    }
    
    func bark(){
        print("\(name) is barking!")
    }
}

let myDog = Dog(name: "Easter")
print(myDog.name)
myDog.bark()

let Dog2 = myDog
print(Dog2.name)
Dog2.name = "Max"
print(Dog2.name)


class Circle{
    private var radius: Double
    private let PI: Double = 3.14159
    
    init(r: Double){
        self.radius = r
    }
    
    public func setRadius(r: Double){
        self.radius = r
    }
    public func getRadius() -> Double{
        return radius
    }
    public func getArea() -> Double{
        return PI * pow(radius, 2)
    }
    public func getDiameter() -> Double{
        return radius * 2
    }
    public func getCircumference() -> Double{
        return radius * 2 * PI
    }
}
var c = Circle(r: 10)
print(c.getArea())
print(c.getCircumference())


class Bulbasaur{
    private var id: Int = 1
    private var level: Int = 1
    
    init(){
        self.id = 1
        self.level = 1
    }
    
    func setLevel(lv: Int){
        self.level = lv
        if level >= 16 && level <= 31{
            self.id = 2
        }
        else if level >= 32 {
            self.id = 3
        } else {
            self.id = 1
        }
    }
    func getLevel() -> Int {
        return self.level
    }
    func getName() -> String{
        switch self.id{
        case 1:
            return "Bulbasaur"
        case 2:
            return "Ivysaur"
        case 3:
            return "Venusaur"
        default:
            return "Bulbasaur"
        }
    }
    func getID() -> Int{
        return self.id
    }
    
}
