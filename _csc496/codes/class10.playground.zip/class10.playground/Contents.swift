import UIKit

class Dog {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    func bark() {
        print("Woof! Woof!")
    }
}

class Poodle: Dog {
    override func bark() {
        print("Yip! Yip!")
    }
}

func printPet(_ pet: Dog) {
    print("\(pet.name) is a \(pet.age) year old pet.")
}
let aPoodle = Poodle(name: "Fifi", age: 5)
printPet(aPoodle)


class Vehicle {}

class Car: Vehicle {
    func beep() {
        print("Beep Beep!")
    }
}

let myVehicle: Vehicle = Car()

// Safe downcasting
if let car = myVehicle as? Car {
    car.beep()
}

// Unsafe downcasting
let forcedDowncastCar = myVehicle as! Car
forcedDowncastCar.beep()


let isVehicle = myVehicle is Vehicle // true
let isCar = myVehicle is Car // true
