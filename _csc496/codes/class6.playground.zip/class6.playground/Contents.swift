import UIKit

struct Car {
    var make: String
    var model: String
}

let myCar = Car(make: "Toyota", model: "Corolla")
print(myCar.make)  // This will print: Toyota
print(myCar.model) // This will print: Corolla


struct Car2 {
    var make: String
    var model: String

    func honk() {
      print("Beep beep! I'm a \(make) \(model).")
    }
}

let myCar2 = Car2(make: "Toyota", model:"Corolla")
myCar2.honk()  // This will print: Beep beep! I'm a Toyota Corolla.

var myCar3 = Car2(make: "Toyota", model:"Corolla")
myCar3.make = "Honda"  // This will change the make of myCar to "Honda"
print(myCar3.make)  // This will print: Honda


struct Car3 {
    var make: String
    var model: String

    mutating func updateMake(newMake: String) {
        self.make = newMake
    }

    func honk() {
        print("Beep beep! I'm a \(make) \(model).")
    }
}

var myCar4 = Car3(make: "Toyota", model: "Corolla")
myCar4.updateMake(newMake: "Honda") // This is valid because myCar3 is declared with 'var' and updateMake is a 'mutating' method.
print(myCar4.make)  // This will print: Honda


struct Rectangle {
    var width: Double
    var height: Double

    var area: Double {
        get {
            return width * height
        }
        set(newArea) {
            // For simplicity, assume a square shape for the new area
            width = sqrt(newArea)
            height = sqrt(newArea)
        }
    }
    
    lazy var expensiveValue: Int = {
        // Some expensive computation
        return 4 // Placeholder value
    }()
}



var score: Int = 0 {
    willSet(newScore) {
        print("About to set score to \(newScore)")
    }
    didSet {
        print("Score was just set from \(oldValue) to \(score)")
    }
}

score = 10


// Structs
struct PersonName{
    // three properties to PersonName
    let givenName: String
    let middleName: String
    var familyName: String
    
    // add a method to combine the three properties into a fullName String
    func fullName() -> String{
        return "\(givenName) \(middleName) \(familyName)"
    }
    
    // provide a method to change the family name property
    // and prefix this method with mutating keyword
    mutating func change(familyName: String){
        self.familyName = familyName
    }
}
var p1 = PersonName(givenName: "Si", middleName: "", familyName: "Chen")
var fullname = p1.fullName()
print(fullname)

// create a person name
// aside from using the struct keyword instead of class.
// the definition of a class and a struct are almost idential
var alissaName = PersonName(givenName: "Alissa", middleName: "May", familyName: "Jones")

// However there is a difference
// Struct a value-type semantics --> when you mutate a struct, you create a copy of the struct with the changed properties

print(alissaName.fullName())

// e.g.,
var alissaCurrentName = alissaName
print(alissaCurrentName.fullName())

alissaName.change(familyName: "Chen")
print(alissaName.fullName())
print(alissaCurrentName.fullName())





class Person{
    let givenName: String
    let middleName: String
    let familyName: String
    var countryOfResidence: String = "UK"
    
    // add an initialization method
    init(givenName: String, middleName: String, familyName: String)
    {
        self.givenName = givenName
        self.middleName = middleName
        self.familyName = familyName
    }
    
    // add a variable as a property of the class, with a computed value
    var displayString: String{
        return "\(self.fullName()) - Location: \(self.countryOfResidence)"
    }
    
    // add a function within the Person class
    func fullName() -> String{
        return "\(givenName) \(middleName) \(familyName)"
    }
}

let Tim = Person(givenName: "AA", middleName: "BB", familyName: "CC")
print(Tim.fullName())
print(Tim.countryOfResidence)
print(Tim.displayString)


// create a Friend class that extends the functionality of the Person class
final class Friend: Person{
    // within the Friend class, add a variable property to hold details of where the user met the friend
    var whereWeMet: String?
    override var displayString: String{
        let meetingPlace = whereWeMet ?? "Done't know where we met"
        return "\(super.displayString) - \(meetingPlace)"
    }
}

let a = Friend(givenName: "DD", middleName: "EE", familyName: "FF")
print(a.fullName())
print(a.whereWeMet)
print(a.displayString)


// In addition to the Friend class, create a Family class that extends the functionality of the Person class

final class Family: Person{
    // add relationship property
    let relationship: String
    init(givenName: String, middleName: String, familyName: String = "Moon", relationship: String){
        self.relationship = relationship
        super.init(givenName: givenName, middleName: middleName, familyName: familyName )
    }
    override var displayString: String{
        return "\(super.displayString) - \(relationship)"
    }
}

let c = Family(givenName: "ZZ", middleName: "YY", familyName: "XX", relationship: "AAA")
print(c.displayString)

































