import UIKit

var greeting = "Hello, playground"

func greet(){
    print("hello world! 🌎")
}
greet()

func returnHello() -> String{
    return "hello world! 🌎"
}
print(returnHello())

func sum(a: Int, b: Int) -> Int{
    var c = a + b
    return c
}
var sum1 = sum(a:1,b:2)
print(sum1)


func greet(person: String, from hometown: String) -> String{
    return "\(person) visit from \(hometown)"
}

let s = greet(person: "Si Chen", from: "Beijing")
print(s)

func sum2(numbers: Int...) -> Int{
    var total = 0
    for num in numbers{
        total += num
    }
    return total
}

let s2 = sum2(numbers: 1, 2, 3, 4, 5, 6, 7)
print(s2)

func doubleInPlace(num: inout Int){
    num *= 2
}

var myNum = 10
doubleInPlace(num: &myNum)
print(myNum)

func convertToCelsius(fahrenheit: Double) -> Double{
    var c = (fahrenheit - 32) * 5 / 9
    return c
}

let tempInCelsius = convertToCelsius(fahrenheit: 98.6)
print(tempInCelsius)


func generateFibonacci(n: Int) -> [Int] {
    if n <= 0 {
        return []
    } else if n == 1 {
        return [0]
    } else if n == 2 {
        return [0, 1]
    } else {
        var res = [0, 1]
        for i in 2...n-1 {
            res.append(res[i - 1] + res[i - 2])
        }
        return res
    }
}
print(generateFibonacci(n: 6))

func a(){
    func b(){
        print("Hello world! 🌎")
    }
    b()
}
a()


func makeIncrementer(incrementAmount: Int) -> () -> Int{
    var total = 0
    func incrementer() -> Int{
        total += incrementAmount
        return total
    }
    return incrementer
}

let incrementByTwo = makeIncrementer(incrementAmount: 2)
print(incrementByTwo())
print(incrementByTwo())
print(incrementByTwo())
print(incrementByTwo())
print(incrementByTwo())
print(incrementByTwo())
print(incrementByTwo())

let incrementByTen = makeIncrementer(incrementAmount: 10)
print(incrementByTen())
print(incrementByTen())
print(incrementByTen())
print(incrementByTen())
print(incrementByTen())


func calculate(a: Int, b: Int) -> Int{
    func multiplier() -> Int{
        return a * b
    }
    var res = multiplier()
    return res
}

print(calculate(a: 5, b: 6))


func makeMultiplier(multiplyAmount: Int) -> () -> Int{
    var total = 1
    func multiplier() -> Int{
        total = total * multiplyAmount
        return total
    }
    return multiplier
}

let multiplyByThree = makeMultiplier(multiplyAmount: 3)
print(multiplyByThree())
print(multiplyByThree())
print(multiplyByThree())


