import SwiftUI

struct ContentView: View {
    @State private var PokemonID = "1"
    
    var pokemonID_num: Int {
        get {
            var PokemonID_Int = Int(PokemonID) ?? 1
            PokemonID_Int = PokemonID_Int - 1
            if PokemonID_Int <= 0{
                PokemonID_Int = 0
            }
            else if PokemonID_Int > 150{
                PokemonID_Int = 150
            }
            return PokemonID_Int
        }
        set(newID) {
            PokemonID = String(newID + 1)
        }
    }
    
    var body: some View {
        VStack {
            Text("Pokedex Ver 2.0")
                .font(.custom("Pokemon-Pixel-Font", size: 36))
            Text(firstGenPokemonNames[pokemonID_num]).font(.custom("Pokemon-Pixel-Font", size: 36))
            TextField("Pokemon ID:", text: $PokemonID)
                .multilineTextAlignment(.center)
                .keyboardType(.numberPad)
                .font(.custom("Pokemon-Pixel-Font", size: 36))
            Image(PokemonID)

        }
        .padding()
    }
}

