//
//  SpriteKitHelper.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import Foundation
import SpriteKit

enum Layer:CGFloat{
    case background
    case foreground
    case player
    case collectible
}
