//
//  GameScene.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    let player = Player()

    func spawnFruit(){
        let collectible = Collectible(collectibleType: CollectibleType.fruit)
        let margin = collectible.size.width * 2
        let dropRange = SKRange(lowerLimit: frame.minX + margin, upperLimit: frame.maxX - margin)
        let randomX = CGFloat.random(in: dropRange.lowerLimit...dropRange.upperLimit)
        
        collectible.position = CGPoint(x: randomX, y: player.position.y * 2.5)
        addChild(collectible)
        collectible.drop(dropSpeed: TimeInterval(1.0), floorLevel: player.frame.minY)
    }
    
    func spawnMultipleFruits(){
        let wait = SKAction.wait(forDuration: TimeInterval(1.0))
        let spawn = SKAction.run{
            self.spawnFruit()
        }
        let sequence = SKAction.sequence([wait, spawn])
        let repeatAction = SKAction.repeat(sequence, count: 30)
        run(repeatAction, withKey: "fruit")
    }
    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "background")
        background.anchorPoint = CGPoint(x: 0, y: 0)
        background.position = CGPoint(x: 10, y: 330)
        background.zPosition = Layer.background.rawValue
        addChild(background)
        
        let foreground = SKSpriteNode(imageNamed: "foreground")
        foreground.anchorPoint = CGPoint(x: 0, y: 0)
        foreground.position = CGPoint(x: 15, y: 158)
        foreground.zPosition = Layer.foreground.rawValue
        addChild(foreground)
        
        
        player.position = CGPoint(x: size.width/2, y: foreground.frame.maxY)
        player.setupConstraints(floor: foreground.frame.maxY)
        addChild(player)
        spawnMultipleFruits()
        
    }
    
    func touchDown(atPoint pos: CGPoint){
        if pos.x < player.position.x{
            player.moveToPosition(pos: pos, direction: "L", speed: 1.0)
        }
        else{
            player.moveToPosition(pos: pos, direction: "R", speed: 1.0)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches{self.touchDown(atPoint: t.location(in: self))}
    }
}
