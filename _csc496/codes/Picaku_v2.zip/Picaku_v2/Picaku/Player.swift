//
//  Player.swift
//  Picaku
//
//  Created by SI CHEN on 11/2/23.
//

import Foundation
import SpriteKit

class Player:SKSpriteNode{
    // MARK: - PROPERTIES
    
    
    // MARK: - INIT
    
    init(){
        let texture = SKTexture(imageNamed: "frame_0")
        
        super.init(texture: texture, color: .clear, size: texture.size())
        
        self.name = "player"
        self.setScale(1.0)
        self.anchorPoint = CGPoint(x: 0.5, y: 0.0)
        self.zPosition = Layer.player.rawValue
    }
    
    required init?(coder aDecoder:NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupConstraints(floor:CGFloat){
        let range = SKRange(lowerLimit: floor, upperLimit: floor)
        let lockToPlatform = SKConstraint.positionY(range)
        constraints = [lockToPlatform]
    }
    
    func moveToPosition(pos:CGPoint, direction: String, speed: TimeInterval){
        switch direction{
        case "L":
            xScale = -abs(xScale)
        default:
            xScale = abs(xScale)
        }
        let moveAction = SKAction.move(to: pos, duration: speed)
        run(moveAction)
    }
}
