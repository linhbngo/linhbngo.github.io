//
//  Collectible.swift
//  Picaku
//
//  Created by student on 11/9/23.
//

import Foundation
import SpriteKit

enum CollectibleType:String{
    case none
    case fruit
}

class Collectible:SKSpriteNode{
    private var collectibleType: CollectibleType = .none
    
    init(collectibleType: CollectibleType){
        var texture: SKTexture!
        self.collectibleType = collectibleType
        
        switch self.collectibleType{
        case .fruit:
            texture = SKTexture.init(imageNamed: "fruit")
        case .none:
            break
        }
        super.init(texture: texture, color: SKColor.clear, size: texture.size())
        
        self.name = "co_\(collectibleType)"
        self.anchorPoint = CGPoint(x: 0.5, y: 1.0)
        self.setScale(0.3)
        self.zPosition = Layer.collectible.rawValue
    }
    
    func drop(dropSpeed:TimeInterval, floorLevel: CGFloat){
        let pos = CGPoint(x: position.x, y: floorLevel)
        let scaleX = SKAction.scaleX(to: 0.5, duration: 1)
        let scaleY = SKAction.scaleY(to: 0.5, duration: 1)
        let scale = SKAction.group([scaleX, scaleY])
        
        let appear = SKAction.fadeAlpha(by: 1, duration: 0.25)
        let moveAction = SKAction.move(to: pos, duration: dropSpeed)
        
        let actionSequence = SKAction.sequence([appear, scale, moveAction])
        
        self.scale(to: CGSize(width: 0.25, height: 1.0))
        self.run(actionSequence, withKey: "drop")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
