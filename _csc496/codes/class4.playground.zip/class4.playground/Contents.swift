import UIKit

var fruits: [String] = ["Apple", "Banana", "Cherry"]

// Accessing
let firstFruit = fruits[0]

// Modifying
fruits.append("Orange")

fruits.remove(at: 1)

for fruit in fruits {
    print("I have a \(fruit).")
}

// Count
let numberOfFruits = fruits.count

// Empty Check
let isEmpty = fruits.isEmpty


// creating an array
var bucketList: [String]
bucketList = ["The last of us: Part I"]
// add new string to the array
bucketList.append("GTA V")
print(bucketList)

// count & remove
print(bucketList.count)
bucketList.remove(at: 1)
print(bucketList)

// subscripting to find your top three items
bucketList.append("Pokemon Go")
bucketList.append("Fallout 4")
bucketList.append("Elden Ring")
print(bucketList[...2])

// array equality
var array1 = ["AAA", "BB", "C"]
var array2 = ["AAA", "BB", "C"]
print(array1 == array2)


// for-in loop
var myFirstInt: Int = 0
for i in 1...5{
    myFirstInt += 1
    print(myFirstInt)
}

// for-in loop with where clause
for i in 1...100 where i % 3 == 0{
    print(i)
}

// While loop
var i = 0
while i < 6
{
    print(i)
    i += 1
}

// repeat-while loops
var j = 0
repeat{
    print(j)
    j += 1
} while j < 6


// Strings

let playground = "Hello Playground"
print(playground)

var greeting = "Hello, playground"
greeting += "!"
print(greeting)

// Characters
for c in greeting{
    print("\(c)")
}

// counting characters
let b = greeting.count
print(b)

//Index and range
//Finding the fifth character
let start = greeting.startIndex
let end = greeting.index(start, offsetBy: 4)
let fifthCharacter = playground[end]

// pulling out a range
let range = start...end
let firstFive = playground[range]
print(firstFive)

let startPlay = greeting.index(greeting.startIndex, offsetBy:6)
let endPlay = greeting.index(startPlay, offsetBy: 3)
let playRange = startPlay...endPlay
let play = playground[playRange]
print(play)

// firstIndex() method
let greeting2 = "Hi there! It's nice to meet you! 👋"
let endOfSentence = greeting2.firstIndex(of: "!")!
let firstSentence = greeting2[...endOfSentence]


// optional type
// converting a String to an Int:
let integer = Int("123")

// result is an optional Int (Int?), which will be nil if the conversion fails.


let validString = "42"
if let validInteger = Int(validString) {
    print("Successfully converted to \(validInteger)")
} else {
    print("Conversion failed")
}

let invalidString = "abc"
let convertedInteger = Int(invalidString) ?? 0
print(convertedInteger)




// nil coalescing operator
let name: String? = nil
let unwrappedName = name ?? "Anonymous"
