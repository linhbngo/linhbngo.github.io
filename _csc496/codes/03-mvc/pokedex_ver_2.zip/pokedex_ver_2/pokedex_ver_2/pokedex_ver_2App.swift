//
//  pokedex_ver_2App.swift
//  pokedex_ver_2
//
//  Created by SI CHEN on 9/11/23.
//

import SwiftUI

@main
struct pokedex_ver_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
