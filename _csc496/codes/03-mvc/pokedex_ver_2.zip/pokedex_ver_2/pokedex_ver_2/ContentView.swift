import SwiftUI

struct ContentView: View {
    @State private var PokemonID = "1"
    

    var body: some View {
        VStack {
            Text("Pokedex Ver 2.0")
                        .font(.custom("Pokemon-Pixel-Font", size: 16))
            
        
            TextField("Pokemon ID:", text: $PokemonID)
                    .multilineTextAlignment(.center)
                    .keyboardType(.numberPad)
                    .font(.custom("Pokemon-Pixel-Font", size: 16))
          
            Image(PokemonID)
            
            if PokemonID == "151" || PokemonID == "150" {
                Image("rare")
                    .resizable()
                    .frame(width: 100, height: 100)
            }
            
        }
        .padding()
    }
    

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
