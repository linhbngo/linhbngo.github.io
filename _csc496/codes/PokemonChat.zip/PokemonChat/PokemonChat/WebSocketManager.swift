import Foundation
import Combine

// WebSocketManager is responsible for handling WebSocket connections and communication.
class WebSocketManager: ObservableObject {
    // The WebSocket task that handles the network communication.
    var webSocketTask: URLSessionWebSocketTask?
    // Published property to store and update player information which SwiftUI views can observe.
    @Published var players: [String: String] = [:]

    // Establishes a WebSocket connection.
    func connectWebSocket() {
        // Creates a WebSocket task with a given URL.
        webSocketTask = URLSession.shared.webSocketTask(with: URL(string: "wss://pokemon.wcpc.fun/ws")!)
        // Starts the WebSocket task.
        webSocketTask?.resume()
        // Starts listening for messages from the WebSocket.
        listen()
    }

    // Sends player information over the WebSocket.
    func updatePlayerInfo(ChatString: String, selectedPokemon: String) {
        // Prepare the player data as a dictionary with the chat string and selected Pokémon.
        let playerData = [ChatString: selectedPokemon]
        // Convert the dictionary into JSON data.
        let jsonData = try? JSONEncoder().encode(playerData)
        // Convert the JSON data to a string representation.
        let jsonString = String(data: jsonData!, encoding: .utf8)

        // Sends the JSON string over the WebSocket.
        webSocketTask?.send(.string(jsonString!)) { error in
            // If there is an error in sending, print an error message.
            if let error = error {
                print("WebSocket sending failed: \(error)")
            }
        }
    }

    // Listens for incoming messages from the WebSocket.
    func listen() {
        // Receives a message from the WebSocket.
        webSocketTask?.receive { [weak self] result in
            switch result {
            case .failure(let error):
                // If there is an error in receiving, print an error message.
                print("WebSocket receive failed: \(error)")
            case .success(let message):
                // Handle a successful message reception.
                switch message {
                case .data(let data):
                    // If the message contains data, decode it into the players dictionary.
                    if let playerList = try? JSONDecoder().decode([String: String].self, from: data) {
                        DispatchQueue.main.async {
                            // Update the players property on the main thread.
                            self?.players = playerList
                        }
                    }
                case .string(let text):
                    // If the message is a string, decode it into the players dictionary.
                    if let data = text.data(using: .utf8),
                       let playerList = try? JSONDecoder().decode([String: String].self, from: data) {
                        DispatchQueue.main.async {
                            // Update the players property on the main thread.
                            self?.players = playerList
                        }
                    }
                @unknown default:
                    // Handle any other kinds of messages (future-proofing).
                    print("Unknown message received.")
                }
            }
            // Calls `listen` again to receive the next message.
            self?.listen()
        }
    }

}
