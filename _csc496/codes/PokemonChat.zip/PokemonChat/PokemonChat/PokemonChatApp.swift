//
//  PokemonChatApp.swift
//  PokemonChat
//
//  Created by SI CHEN on 10/2/23.
//

import SwiftUI

@main
struct PokemonChatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
