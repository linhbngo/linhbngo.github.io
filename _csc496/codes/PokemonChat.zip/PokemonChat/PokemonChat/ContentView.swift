import SwiftUI

struct ContentView: View {
    // This observed object is presumably a view model that manages WebSocket communication.
    @ObservedObject var webSocketManager = WebSocketManager()

    // State variables to hold the currently selected Pokémon ID and chat strings.
    @State private var selectedPokemon: String = "1"
    @State private var ChatString: String = "..."
    @State private var tempChatString: String = "..."

    var body: some View {
        VStack {
            // A text field for the user to enter chat messages.
            TextField("Enter your message", text: $tempChatString)
                .font(.system(size: 20)) // Sets the font size of the text inside the TextField.
                .padding(12) // Adds padding around the TextField content.
                .frame(minHeight: 100) // Sets a minimum height for the TextField.
                .background(Color.white) // Sets the background color of the TextField.
                .cornerRadius(25) // Rounds the corners of the TextField background.
                .overlay(
                    // Adds a gray stroke around the TextField.
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color.gray, lineWidth: 1)
                )
                .padding(.horizontal, 20) // Adds horizontal padding to the TextField.

            // A button that, when tapped, sends the chat message.
            Button("Send Chat") {
                // Updates the chat string with the user's input from the text field.
                ChatString = tempChatString
                // Calls a method on the WebSocket manager to update player information.
                webSocketManager.updatePlayerInfo(ChatString: ChatString, selectedPokemon: selectedPokemon)
            }
            .padding() // Adds padding around the button.

            ScrollView {
                VStack {
                    ForEach(1...151, id: \.self) { num in
                        Button(action: {
                            self.selectedPokemon = String(num)
                        }) {
                            HStack {
                                Text("No. \(num)")
                                Spacer()
                                // Optionally, you could show a checkmark or other indicator for the selected item
                                if selectedPokemon == String(num) {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.blue)
                                }
                            }
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(self.selectedPokemon == String(num) ? Color.blue.opacity(0.2) : Color.clear)
                        .foregroundColor(.black)
                    }
                }
            }

            // Displays an image of the selected Pokémon.
            Image(selectedPokemon)
                .resizable() // Makes the image resizable.
                .scaledToFit() // Scales the image to fit within its frame while maintaining its aspect ratio.
                .frame(width: 100, height: 100) // Sets the frame of the image.

            // A list that displays all connected players and their chosen Pokémon.
            List(webSocketManager.players.keys.sorted(), id: \.self) { player in
                HStack {
                    Text(player) // The player's name.
                    Spacer() // Pushes the content to opposite sides.
                    Image(webSocketManager.players[player]!) // The player's Pokémon image.
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                }
            }
        }
        .onAppear {
            // Connects to the WebSocket when the view appears.
            webSocketManager.connectWebSocket()
        }
        .onChange(of: selectedPokemon) { newValue in
            // Updates the player info when the selected Pokémon changes.
            webSocketManager.updatePlayerInfo(ChatString: ChatString, selectedPokemon: selectedPokemon)
        }
    }
}
